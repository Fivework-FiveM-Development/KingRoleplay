local ESX = GetResourceState('es_extended'):find('start') and exports['es_extended']:getSharedObject() or nil

if not ESX then return end

function Notification(msg)
    ESX.ShowNotification(msg)
end